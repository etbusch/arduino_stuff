#include <stdint.h>
int32_t CPU_BD_get_mbyte(int32_t);
int32_t CPU_BD_get_mword(int32_t);
void CPU_BD_put_mbyte(int32_t, int32_t);
void CPU_BD_put_mword(int32_t, int32_t);
void WriteToConsol(char*);

